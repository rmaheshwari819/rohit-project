package us.koller.todolist.Util.Callbacks;

/**
 * Created by Lukas on 20.10.2016.
 */

public interface AlarmInfoDialogOnPositiveCallback {
    void onPositive();
}
