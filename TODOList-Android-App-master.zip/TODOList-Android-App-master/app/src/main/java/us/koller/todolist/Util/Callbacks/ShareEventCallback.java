package us.koller.todolist.Util.Callbacks;

/**
 * Created by Lukas on 15.08.2016.
 */
public interface ShareEventCallback {
    void shareEvents();
    void cancel();
}
