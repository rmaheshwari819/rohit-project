package us.koller.todolist.Util.Callbacks;

import android.view.View;

/**
 * Created by Lukas on 23.09.2016.
 */

public interface ColorSelectedCallback {
    void colorSelected(View v, int colorIndex);
}
