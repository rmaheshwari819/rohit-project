package us.koller.todolist.Util.Callbacks;

/**
 * Created by Lukas on 13.06.2016.
 */
public interface ColorPickerDialogCallback {
    void colorPicked(int red, int green, int blue, int textColor);
}
